package com.devil.adapter;

import java.util.ArrayList;
import java.util.List;

import com.devil.R;
import com.devil.bean.SignDto;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 
 * @ClassName: ZGSignAdapter
 * @Description: 首页的签到信息列表
 * @date 2016年7月3日 下午10:45:43
 *
 */
public class ZGSignAdapter extends BaseAdapter {
	private Context context;
	private List<SignDto> data;
	private int isZg = 0;// 0 主管,1 员工 2-员工显示

	public ZGSignAdapter(Context context, List<SignDto> list, int isZg) {
		this.context = context;
		this.data = new ArrayList<SignDto>();
		this.isZg = isZg;
	}

	public void setData(List<SignDto> data) {
		this.data = data;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int arg0) {
		return data.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(context,
					R.layout.activity_home_sign_item, null);
			holder.tv_text = (TextView) convertView
					.findViewById(R.id.sign_text);
			holder.tv_time = (TextView) convertView
					.findViewById(R.id.sign_time);
			holder.tv_status = (TextView) convertView
					.findViewById(R.id.sign_status);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		SignDto info = data.get(position);
		if (isZg == 0) {
			holder.tv_text.setText(info.getSign_des());
			holder.tv_status.setText("签到码:" + info.getSign_pass());
			holder.tv_time.setText(info.getSign_time());
		} else if (isZg == 1) {
			holder.tv_text.setText(info.getU_name());
			if (info.getSign_status() == 0)
				holder.tv_status.setText("未签到");
			else
				holder.tv_status.setText("已签到");
			holder.tv_time.setText(info.getSign_code());
		} else if (isZg == 2) {// 首页员工签到信息显示
			holder.tv_text.setText(info.getSign_des());
			if (info.getSign_status() == 0)
				holder.tv_status.setText("未签到");
			else
				holder.tv_status.setText("已签到");
			holder.tv_time.setText(info.getSign_time());
		}
		return convertView;
	}

	class ViewHolder {
		private TextView tv_text;
		private TextView tv_time;
		private TextView tv_status;
	}
}
