package com.devil.adapter;

import java.util.ArrayList;
import java.util.List;

import com.devil.R;
import com.devil.bean.UserDto;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 
 * @ClassName: YGListAdapter
 * @Description: 员工列表
 * @date 2016年7月3日 下午4:53:49
 *
 */
public class YGListAdapter extends BaseAdapter {
	private Context context;
	private List<UserDto> data;

	public YGListAdapter(Context context, List<UserDto> list) {
		this.context = context;
		this.data = new ArrayList<UserDto>();
	}

	public void setData(List<UserDto> data) {
		this.data = data;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int arg0) {
		return data.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(context, R.layout.activity_all_yg_item,
					null);
			holder.tv_nick = (TextView) convertView
					.findViewById(R.id.yg_nick);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		UserDto info = data.get(position);
		holder.tv_nick.setText(info.getUser_nickName());
		return convertView;
	}

	class ViewHolder {
		private TextView tv_nick;
	}

}
