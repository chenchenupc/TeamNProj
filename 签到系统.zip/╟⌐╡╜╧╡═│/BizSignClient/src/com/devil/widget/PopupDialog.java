package com.devil.widget;


import com.devil.R;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class PopupDialog extends Dialog implements android.view.View.OnClickListener {

    private PopupDialog(Context context, boolean flag, OnCancelListener listener) {
        super(context, flag, listener);
    }

    @SuppressLint("InflateParams")
    public PopupDialog(Context context, int theme, int layout) {
        super(context, theme);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setContentView(layout);
    }

    public PopupDialog(Context context, int layout) {
        this(context, R.style.dialog_share, layout);
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setGravity(Gravity.BOTTOM);

        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay();
        WindowManager.LayoutParams p = getWindow().getAttributes();
        p.width = d.getWidth();
        getWindow().setAttributes(p);
    }

    @Override
    public void onClick(View v) {
        if (listener != null) {
            listener.onPlatformClick(v.getId());
        }
    }

    private OnPlatformClickListener listener;

    public void setOnPlatformClick(OnPlatformClickListener listener) {
        this.listener = listener;
    }

    public interface OnPlatformClickListener {

        void onPlatformClick(int id);
    }
}
