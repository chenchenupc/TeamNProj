package com.devil.widget;

import com.devil.R;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewTreeObserver;
import android.widget.EditText;

/**
 * 自定义一个输入框,带清空功能的
 */
public class IputEditText extends EditText {

	private EditText mEditText;

	public Drawable cancleDrawable;

	private int cancleSpaceX;

	private int touchMode;

	private final static int NORMAL = 10;
	private final static int CANCLE = 11;

	public IputEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
		mEditText = this;
		initEditTextAttr(context);
	}

	public void computeCancleSpace(int width) {
		cancleSpaceX = width - cancleDrawable.getMinimumWidth();
	}

	private void initEditTextAttr(Context context) {
		if (mEditText == null) {
			try {
				throw new Exception("please create IputEditText from xml ");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// mEditText.setBackgroundResource(R.drawable.leba_shape_bg) ;
		mEditText.setSingleLine(true);
		mEditText.setPadding(15, 0, 8, 0);

		cancleDrawable = context.getResources().getDrawable(
				R.drawable.bg_text_delete);
		cancleDrawable.setBounds(0, 0, cancleDrawable.getMinimumWidth(),
				cancleDrawable.getMinimumHeight());

		if (mEditText.getText().toString().length() > 0) {
			mEditText.setCompoundDrawables(null, null, cancleDrawable, null);
		} else {
			mEditText.setCompoundDrawables(null, null, null, null);
		}

		mEditText.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				if (s.toString().length() > 0) {
					mEditText.setCompoundDrawables(null, null, cancleDrawable,
							null);
				} else {
					mEditText.setCompoundDrawables(null, null, null, null);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
			}
		});

		// 监听获取到控件的宽和高
		ViewTreeObserver vto = mEditText.getViewTreeObserver();
		vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
			public boolean onPreDraw() {
				int width = mEditText.getMeasuredWidth();
				computeCancleSpace(width);
				return true;
			}
		});

	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int startX = (int) event.getX();

			if (startX > cancleSpaceX) {
				touchMode = CANCLE;
			} else {
				touchMode = NORMAL;
			}
		} else if (event.getAction() == MotionEvent.ACTION_UP) {
			if (touchMode == CANCLE && event.getX() > cancleSpaceX) {
				mEditText.setText("");
			}
		}
		return super.onTouchEvent(event);
	}
}
