package com.devil.fragment;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.devil.GetYgSignStatusActivity;
import com.devil.R;
import com.devil.adapter.ZGSignAdapter;
import com.devil.bean.ResMessage;
import com.devil.bean.SignDto;
import com.devil.config.Contants;
import com.devil.utils.DevilUtil;
import com.devil.utils.HttpUtil;
import com.devil.utils.JsonUtil;
import com.devil.widget.CustomDialog;
import com.devil.widget.EmptyLayout;
import com.devil.widget.XListView;
import com.devil.widget.XListView.IXListViewListener;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.RelativeLayout;

/**
 * 
 * @ClassName: HomeFragment
 * @Description: 签到首页界面,员工登录显示所有签到信息,主管登录显示自己发布的签到信息
 * @date 2016年7月3日 下午3:56:48
 *
 */
public class HomeFragment extends BaseFragment implements OnClickListener,
		IXListViewListener, OnItemClickListener {
	private RelativeLayout rl_main;
	private LayoutInflater _inflater;
	private ImageView iv_add;
	private boolean isZg = false;
	// 自定义listview
	private XListView Xlv;
	private EmptyLayout mEmptyLayout;
	private ZGSignAdapter stuAdatper;
	private Handler mHandler = new Handler();
	private List<SignDto> datas = new ArrayList<SignDto>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_fragment_home, null);
		try {
			initView(view);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return view;
	}

	private void initView(View v) {
		rl_main = (RelativeLayout) v.findViewById(R.id.homeFrame);
		_inflater = LayoutInflater.from(getActivity());
		iv_add = (ImageView) v.findViewById(R.id.home_title_btn);
		iv_add.setOnClickListener(this);
		setMainContentView(R.layout.activity_all_yg);
		if (ta.getUser().getUser_role() == 0) {// 主管
			isZg = true;
			stuAdatper = new ZGSignAdapter(getActivity(), datas, 0);
		} else if (ta.getUser().getUser_role() == 1) {// 员工
			iv_add.setVisibility(View.INVISIBLE);
			isZg = false;
			stuAdatper = new ZGSignAdapter(getActivity(), datas, 2);
		}
		Xlv = (XListView) rl_main.findViewById(R.id.all_yg_list);
		Xlv.setAdapter(stuAdatper);
		Xlv.setOnItemClickListener(this);
		Xlv.setPullLoadEnable(false);// 上拉加载
		Xlv.setXListViewListener(this);// 上下拉监听
		mEmptyLayout = new EmptyLayout(getActivity(), Xlv);
		mEmptyLayout.setErrorButtonClickListener(mErrorClickListener);
		loadData();
	}

	private View.OnClickListener mErrorClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			mEmptyLayout.showLoading();
		}
	};

	private void setMainContentView(int layoutId) {
		ViewGroup layout = (ViewGroup) _inflater.inflate(layoutId, null);
		ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT);
		rl_main.removeAllViews();
		rl_main.addView(layout, layoutParams);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.home_title_btn:
			zgSendSign();
			break;

		default:
			break;
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		loadData();
	}

	@Override
	public void onRefresh() {
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				ta.setResDefaultTime(DevilUtil.getCurrentTime());
				onLoad();
			}
		}, 2000);
	}

	@Override
	public void onLoadMore() {
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				onLoad();
			}
		}, 2000);
	}

	private void onLoad() {
		Xlv.stopRefresh();
		Xlv.stopLoadMore();
		Xlv.setRefreshTime(ta.getResDefaultTime());
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		Intent intent;
		if (isZg) {// 主管
			intent = new Intent(getActivity(), GetYgSignStatusActivity.class);
			intent.putExtra("sign", JsonUtil.format(datas.get(arg2 - 1)));
			startActivity(intent);
		} else {// 员工签到
			if (datas.get(arg2 - 1).getSign_status() == 1)
				return;
			ygDoSign(datas.get(arg2 - 1));
		}
	}

	private void loadData() {
		if (ta.getUser().getUser_role() == 0) {// 主管
			new ZGGetAllSigns().execute(JsonUtil.format(ta.getUser()));
		} else {// 员工
			new YGGetSigns().execute(JsonUtil.format(ta.getUser()));
		}
	}

	/**
	 * 
	 * @ClassName: ZGGetAllSigns
	 * @Description: 主管获取自己发布的所有签到信息
	 * @date 2016年7月3日 下午11:48:22
	 *
	 */
	private class ZGGetAllSigns extends AsyncTask<String, Void, String> {

		String url = Contants.BASE_URL + Contants.ZG_ALL_SIGNS;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mEmptyLayout.showLoading();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getActivity(), msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						datas = JsonUtil.parseList(msg.getRES_DATA(),
								SignDto[].class);
						if (datas.size() < 1) {
							mEmptyLayout.showEmpty();
						} else {
							stuAdatper.setData(datas);
							stuAdatper.notifyDataSetChanged();
						}
					}
				} catch (Exception e) {
					Toast.makeText(getActivity(), res, Toast.LENGTH_SHORT)
							.show();
					mEmptyLayout.showError();
				}
			}

		}
	}

	/**
	 * 
	 * @ClassName: YGGetSigns
	 * @Description:员工获取发布给自己的签到信息
	 * @date 2016年7月3日 下午11:47:18
	 *
	 */
	private class YGGetSigns extends AsyncTask<String, Void, String> {

		String url = Contants.BASE_URL + Contants.YG_GET_SIGN;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mEmptyLayout.showLoading();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getActivity(), msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						datas = JsonUtil.parseList(msg.getRES_DATA(),
								SignDto[].class);
						if (datas.size() < 1) {
							mEmptyLayout.showEmpty();
						} else {
							stuAdatper.setData(datas);
							stuAdatper.notifyDataSetChanged();
						}
					}
				} catch (Exception e) {
					Toast.makeText(getActivity(), res, Toast.LENGTH_SHORT)
							.show();
					mEmptyLayout.showError();
				}
			}

		}
	}

	// 主管发布签到
	private void zgSendSign() {
		final CustomDialog.Builder builder = new CustomDialog.Builder(
				getActivity());
		final String pass = getSignPass();
		builder.setMessage("随机签到码:" + pass);
		builder.setEditText(true, "请输入签到描述信息...");
		builder.setTitle(Contants.DIALOG_TITLE);
		builder.setPositiveButton(Contants.DIALOG_OK,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						final String code = builder.getEditStr();
						if (code == null || code.equals("")) {
							Toast.makeText(getActivity(), "描述信息不能为空!",
									Toast.LENGTH_SHORT).show();
							return;
						}
						SignDto sd = new SignDto();
						sd.setSign_code(UUID.randomUUID().toString());
						sd.setSign_des(code);
						sd.setSign_pass(pass);
						sd.setSign_status(0);
						sd.setU_id(ta.getUser().getId());
						sd.setU_role(ta.getUser().getUser_role());
						new ZGAddSign().execute(JsonUtil.format(sd));
						dialog.dismiss();
					}
				});
		builder.setNegativeButton(R.string.text_cancel,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		Dialog d = builder.create();
		builder.setEditType(InputType.TYPE_CLASS_TEXT);
		d.setCanceledOnTouchOutside(false);
		d.show();
	}

	private String getSignPass() {
		Random random = new Random();
		String result = "";
		for (int i = 0; i < 6; i++) {
			result += random.nextInt(10);
		}
		return result;

	}

	/**
	 * 
	 * @ClassName: ZGAddSign
	 * @Description: 主管发布签到
	 * @date 2016年7月3日 下午10:33:16
	 *
	 */
	private class ZGAddSign extends AsyncTask<String, Void, String> {

		String url = Contants.BASE_URL + Contants.ZG_ADD_SIGN;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			showLoadingDialog();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			dismissLoadingDialog();
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getActivity(), msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						loadData();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
	}

	// 员工签到
	private void ygDoSign(final SignDto sdd) {
		final CustomDialog.Builder builder = new CustomDialog.Builder(
				getActivity());
		builder.setEditText(true, "请输入签到码...");
		builder.setTitle(Contants.DIALOG_TITLE);
		builder.setPositiveButton(Contants.DIALOG_OK,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						final String code = builder.getEditStr();
						if (code == null || code.equals("")) {
							Toast.makeText(getActivity(), "签到码不能为空!",
									Toast.LENGTH_SHORT).show();
							return;
						}
						SignDto sd = sdd;
						sd.setSign_pass(code);
						new YGDoSign().execute(JsonUtil.format(sd));
						dialog.dismiss();
					}
				});
		builder.setNegativeButton(R.string.text_cancel,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		Dialog d = builder.create();
		builder.setEditType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
		d.setCanceledOnTouchOutside(false);
		d.show();
	}

	/**
	 * 
	 * @ClassName: YGDoSign
	 * @Description: 员工签到
	 * @date 2016年7月3日 下午10:33:16
	 *
	 */
	private class YGDoSign extends AsyncTask<String, Void, String> {

		String url = Contants.BASE_URL + Contants.YG_DO_SIGN;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			showLoadingDialog();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			dismissLoadingDialog();
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getActivity(), msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						loadData();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
	}
}
