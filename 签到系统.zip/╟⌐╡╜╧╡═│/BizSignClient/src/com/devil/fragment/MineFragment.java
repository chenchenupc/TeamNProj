package com.devil.fragment;

import com.devil.AppManager;
import com.devil.EditUserActivity;
import com.devil.GetAllYGListActivity;
import com.devil.LoginActivity;
import com.devil.R;
import com.devil.config.Contants;
import com.devil.utils.JsonUtil;
import com.devil.widget.CustomDialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 
 * @ClassName: MineFragment
 * @Description: 个人界面,员工查看个人信息,主管编辑员工信息
 * @author A18ccms a18ccms_gmail_com
 * @date 2016年7月3日 下午3:57:31
 *
 */
public class MineFragment extends BaseFragment implements OnClickListener {
	private RelativeLayout rl_main;
	private LayoutInflater _inflater;
	private boolean isZg = false;// 是否是主管

	TextView tv_name;

	LinearLayout ll_about;// 关于
	LinearLayout ll_advice;// 建议
	LinearLayout ll_exit;// 退出

	ImageView iv_Refresh;

	LinearLayout ll_edit;// 编辑/查看
	TextView tv_edit;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_fragment_tools, null);
		try {
			initView(view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return view;
	}

	private void initView(View v) {
		rl_main = (RelativeLayout) v.findViewById(R.id.mineFrame);
		_inflater = LayoutInflater.from(getActivity());
		iv_Refresh = (ImageView) v.findViewById(R.id.mine_title_btn);
		iv_Refresh.setOnClickListener(this);
		if (ta.getRole() == 0) {
			isZg = true;
		} else {
			isZg = false;
		}
		setMainContentView(R.layout.activity_user_info);
		tv_name = (TextView) rl_main.findViewById(R.id.user_name);
		tv_name.setText(ta.getUser().getUser_nickName() + ",欢迎您使用"
				+ getResources().getString(R.string.app_name) + "!");
		ll_about = (LinearLayout) rl_main.findViewById(R.id.mine_about);
		ll_about.setOnClickListener(this);
		ll_advice = (LinearLayout) rl_main.findViewById(R.id.mine_advice);
		ll_advice.setOnClickListener(this);
		ll_exit = (LinearLayout) rl_main.findViewById(R.id.mine_exit);
		ll_exit.setOnClickListener(this);
		ll_edit = (LinearLayout) rl_main.findViewById(R.id.edit_yg);
		ll_edit.setOnClickListener(this);
		tv_edit = (TextView) rl_main.findViewById(R.id.edit_text);
		if (!isZg)
			tv_edit.setText("查看个人信息");
		iv_Refresh.setVisibility(View.INVISIBLE);
	}

	private void setMainContentView(int layoutId) {
		ViewGroup layout = (ViewGroup) _inflater.inflate(layoutId, null);
		ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT);
		rl_main.removeAllViews();
		rl_main.addView(layout, layoutParams);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.edit_yg:
			if (isZg) {// 主管
				startActivity(new Intent(getActivity(),
						GetAllYGListActivity.class));
			} else {// 员工
				Intent intent = new Intent(getActivity(),
						EditUserActivity.class);
				intent.putExtra("from", "mine");
				startActivity(intent);
			}
			break;
		case R.id.mine_advice:
			mineAdvice();
			break;
		case R.id.mine_about:
			mineAbout();
			break;
		case R.id.mine_exit:
			confirm();
			break;
		default:
			break;
		}
	}

	private void mineAbout() {
		final CustomDialog.Builder builder = new CustomDialog.Builder(
				getActivity());
		builder.setTitle(Contants.DIALOG_TITLE);
		builder.setMessage("移动签到,是一款真正能改变传统管理员工方式的App!");
		builder.setPositiveButton(Contants.DIALOG_OK,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		Dialog d = builder.create();
		d.setCanceledOnTouchOutside(false);
		d.show();
	}

	private void mineAdvice() {
		final CustomDialog.Builder builder = new CustomDialog.Builder(
				getActivity());
		builder.setEditText(true, "请提出您宝贵的建议或意见");
		builder.setTitle(Contants.DIALOG_TITLE);
		builder.setPositiveButton(Contants.DIALOG_OK,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						final String code = builder.getEditStr();
						if (code == null || code.equals("")) {
							Toast.makeText(getActivity(), "请说点什么吧.",
									Toast.LENGTH_SHORT).show();
							return;
						}
						Toast.makeText(getActivity(), "您的反馈已提交,谢谢.",
								Toast.LENGTH_SHORT).show();
						dialog.dismiss();
					}
				});
		builder.setNegativeButton(R.string.text_cancel,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		Dialog d = builder.create();
		builder.setEditType(InputType.TYPE_CLASS_TEXT);
		d.setCanceledOnTouchOutside(false);
		d.show();
	}

	private void confirm() {
		final CustomDialog.Builder builder = new CustomDialog.Builder(
				getActivity());
		builder.setTitle(Contants.DIALOG_TITLE);
		builder.setMessage("确定要退出当前用户吗?");
		builder.setPositiveButton(Contants.DIALOG_OK,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						startActivity(new Intent(getActivity(),
								LoginActivity.class));
						AppManager.getAppManager().finishActivity();// 结束当前activity
						dialog.dismiss();

					}
				});
		builder.setNegativeButton(R.string.text_cancel,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		Dialog d = builder.create();
		d.setCanceledOnTouchOutside(false);
		d.show();
	}
}
