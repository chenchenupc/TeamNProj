package com.devil.bean;

/**
 * 
 * @ClassName: UserDto
 * @Description: 用户信息表
 * @date 2016年7月3日 上午11:54:27
 *
 */
public class UserDto {
	private int id;// ID
	private String user_loginName;// 登录名
	private String user_pass;// 密码
	private String user_nickName;// 昵称
	private int user_role;// 0:主管 1:员工
	private String user_name;// 姓名
	private String user_sex;// 性别
	private String user_id;// 身份证号
	private String user_icon;// 员工头像
	private int user_status;// 员工信息状态

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUser_loginName() {
		return user_loginName;
	}

	public void setUser_loginName(String user_loginName) {
		this.user_loginName = user_loginName;
	}

	public String getUser_pass() {
		return user_pass;
	}

	public void setUser_pass(String user_pass) {
		this.user_pass = user_pass;
	}

	public String getUser_nickName() {
		return user_nickName;
	}

	public void setUser_nickName(String user_nickName) {
		this.user_nickName = user_nickName;
	}

	public int getUser_role() {
		return user_role;
	}

	public void setUser_role(int user_role) {
		this.user_role = user_role;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_sex() {
		return user_sex;
	}

	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_icon() {
		return user_icon;
	}

	public void setUser_icon(String user_icon) {
		this.user_icon = user_icon;
	}

	public int getUser_status() {
		return user_status;
	}

	public void setUser_status(int user_status) {
		this.user_status = user_status;
	}

}
