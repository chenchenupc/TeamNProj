package com.devil.bean;

/**
 * 
 * @ClassName: SignDto
 * @Description: 签到信息实体类
 * @date 2016年7月3日 上午11:58:47
 *
 */
public class SignDto {
	private int id;// ID
	private String sign_code;// 签到编号
	private String sign_des;// 签到内容简述
	private String sign_time;// 签到发布时间
	private int sign_status;// 签到状态 0:待签到 1:已签到
	private String sign_pass;// 签到密码
	private int u_id;// 用户ID
	private int u_role;// 用户角色
	private String u_name;// 员工姓名

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSign_code() {
		return sign_code;
	}

	public void setSign_code(String sign_code) {
		this.sign_code = sign_code;
	}

	public String getSign_des() {
		return sign_des;
	}

	public void setSign_des(String sign_des) {
		this.sign_des = sign_des;
	}

	public String getSign_time() {
		return sign_time;
	}

	public void setSign_time(String sign_time) {
		this.sign_time = sign_time;
	}

	public int getSign_status() {
		return sign_status;
	}

	public void setSign_status(int sign_status) {
		this.sign_status = sign_status;
	}

	public String getSign_pass() {
		return sign_pass;
	}

	public void setSign_pass(String sign_pass) {
		this.sign_pass = sign_pass;
	}

	public int getU_id() {
		return u_id;
	}

	public void setU_id(int u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public int getU_role() {
		return u_role;
	}

	public void setU_role(int u_role) {
		this.u_role = u_role;
	}

}
