package com.devil;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.config.Contants;
import com.devil.utils.HttpUtil;
import com.devil.utils.JsonUtil;
import com.devil.utils.PublicUtil;

import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 登录界面
 *
 */
public class LoginActivity extends BaseActivity {
	private EditText et_name;
	private EditText et_pass;
	private TextView tv_regist;
	private String name;
	private String pass;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_login);
		setTitle("登录");
		setVisibileBackBtn(false);
		et_name = (EditText) this.findViewById(R.id.username_edit);
		et_pass = (EditText) this.findViewById(R.id.password_edit);
		PublicUtil.showPassMode(et_pass);
		tv_regist = (TextView) this.findViewById(R.id.buttom_id);
		tv_regist.setOnClickListener(new regist());
	}

	/**
	 * 登录按钮
	 */
	public void viewClick(View v) {
		name = et_name.getText().toString();
		pass = et_pass.getText().toString();
		if (name == null || name.equals("")) {
			PublicUtil.setFocus(et_name);
			Toast.makeText(LoginActivity.this, "还没有输入用户名哦!", Toast.LENGTH_SHORT)
					.show();
		} else if (pass == null || pass.equals("")) {
			PublicUtil.setFocus(et_pass);
			Toast.makeText(LoginActivity.this, "还没有输入密码哦!", Toast.LENGTH_SHORT)
					.show();
		} else {
			UserDto loginDto = new UserDto();
			loginDto.setUser_loginName(name);
			loginDto.setUser_pass(pass);
			String str = JsonUtil.format(loginDto);
			new Login().execute(str);
		}
	}

	/**
	 * 异步请求方式登录
	 */
	private class Login extends AsyncTask<String, Void, String> {
		ProgressDialog mProcessDialog = null;

		String url = Contants.BASE_URL + Contants.LOGIN_URL;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProcessDialog = new ProgressDialog(LoginActivity.this);
			mProcessDialog.setCancelable(false);
			mProcessDialog.setMessage("请求处理中,请稍后...");
			mProcessDialog.show();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			mProcessDialog.dismiss();
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getApplicationContext(),
							msg.getRES_MESSAGE(), Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						ta.setUser(JsonUtil.parse(msg.getRES_DATA(),
								UserDto.class));
						Intent intent = new Intent(LoginActivity.this,
								MainActivity.class);
						startActivity(intent);
						finish();
					}
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(), res,
							Toast.LENGTH_SHORT).show();
				}
			}

		}
	}

	/**
	 * 注册链接跳转
	 * 
	 */
	private final class regist implements OnClickListener {
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(LoginActivity.this, RegistActivity.class);
			startActivityForResult(intent, 1);
		}

	}

	/**
	 * 回调函数、获取注册返回的用户名、密码
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (data == null) {
			return;
		}
		// 注册返回
		String _name = data.getExtras().getString("loginName");
		et_name.setText(_name);
	}

	/**
	 * 按Back键处理
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			showExitAlert();
		}
		return super.onKeyDown(keyCode, event);
	}

	// 登录界面按Back键退出
	private void showExitAlert() {
		Builder builder = new Builder(LoginActivity.this);
		builder.setIcon(R.drawable.ic_launcher);
		builder.setTitle("确定离开吗?");
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				app.AppExit(getApplicationContext());
			}
		});
		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				dialog.cancel();
			}
		});
		LayoutInflater inflater = getLayoutInflater();
		View layout = inflater.inflate(R.layout.activity_dialog,
				(ViewGroup) findViewById(R.id.myLayout));
		builder.setView(layout);
		builder.show();
	}
}
