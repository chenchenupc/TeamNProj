package com.devil;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.config.Contants;
import com.devil.utils.HttpUtil;
import com.devil.utils.JsonUtil;
import com.devil.utils.PublicUtil;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

/**
 * 注册界面处理
 *
 */
public class RegistActivity extends BaseActivity {
	private EditText et_loginname;
	private EditText et_nickname;
	private EditText et_pass;
	private EditText et_passagain;

	private UserDto registerDto;
	private String loginname;
	private String pass;

	@ViewInject(R.id.rg_role)
	RadioGroup rg_role;
	@ViewInject(R.id.rg_stu)
	RadioButton rg_stu;
	@ViewInject(R.id.rg_tea)
	RadioButton rg_tea;

	private int role = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_register);
		setTitle("注册");
		et_loginname = (EditText) this.findViewById(R.id.loginNameValue);
		et_nickname = (EditText) this.findViewById(R.id.nickNameValue);
		et_pass = (EditText) this.findViewById(R.id.passValue);
		PublicUtil.showPassMode(et_pass);
		et_passagain = (EditText) this.findViewById(R.id.passAgain);
		PublicUtil.showPassMode(et_passagain);
		ViewUtils.inject(this);
		rg_role.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup arg0, int index) {
				if (arg0.getCheckedRadioButtonId() == R.id.rg_stu) {
					role = 1;
				} else {
					role = 0;
				}
			}
		});

	}

	/**
	 * 注册按钮点击
	 * 
	 * @param v
	 */
	public void registBT(View v) {
		loginname = et_loginname.getText().toString();
		String nickname = et_nickname.getText().toString();
		pass = et_pass.getText().toString();
		String passagain = et_passagain.getText().toString();
		if (loginname.equals("") || loginname == null) {
			PublicUtil.setFocus(et_loginname);
			Toast.makeText(RegistActivity.this, "用户名不能为空!", Toast.LENGTH_SHORT)
					.show();
		} else if (nickname.equals("") || nickname == null) {
			PublicUtil.setFocus(et_nickname);
			Toast.makeText(RegistActivity.this, "昵称不能为空!", Toast.LENGTH_SHORT)
					.show();
		} else if (pass.equals("") || pass == null) {
			PublicUtil.setFocus(et_pass);
			Toast.makeText(RegistActivity.this, "密码不能为空!", Toast.LENGTH_SHORT)
					.show();
		} else if (!(passagain.equals(pass))) {
			PublicUtil.setFocus(et_passagain);
			Toast.makeText(RegistActivity.this, "与上一次输入不匹配!",
					Toast.LENGTH_SHORT).show();
		} else {
			registerDto = new UserDto();
			registerDto.setUser_loginName(loginname);
			registerDto.setUser_nickName(nickname);
			registerDto.setUser_pass(pass);
			registerDto.setUser_role(role);
			String str = JsonUtil.format(registerDto);
			new Register().execute(str);
		}
	}

	/**
	 * 异步请求方式注册用户
	 */
	private class Register extends AsyncTask<String, Void, String> {
		ProgressDialog mProcessDialog = null;
		String url = Contants.BASE_URL + Contants.REGIST_URL;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProcessDialog = new ProgressDialog(RegistActivity.this);
			mProcessDialog.setCancelable(false);
			mProcessDialog.setMessage("请求处理中,请稍后...");
			mProcessDialog.show();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			mProcessDialog.dismiss();
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(getApplicationContext(),
							msg.getRES_MESSAGE(), Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						finishThis();
					}
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(), res,
							Toast.LENGTH_SHORT).show();
				}
			}

		}
	}

	/**
	 * 返回登录之前设置参数
	 */
	private void finishThis() {
		Intent intent = new Intent();
		intent.putExtra("loginName", loginname);
		intent.putExtra("loginPass", pass);
		setResult(1, intent);
		this.finish();
	}
}
