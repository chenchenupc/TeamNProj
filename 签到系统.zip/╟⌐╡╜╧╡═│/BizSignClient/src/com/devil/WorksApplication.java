package com.devil;

import com.devil.bean.UserDto;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * Application级别全局变量处理
 */
public class WorksApplication extends Application {
	private final static String TAG = "WorksApplication";
	private UserDto user;
	private int role = -1;
	private SharedPreferences _preferences = null;
	private String RES_DEFAULT_TIME = "works_default_time";// 默认列表下拉刷新时间

	@Override
	public void onCreate() {
		super.onCreate();
		user = new UserDto();
		_preferences = getSharedPreferences(TAG, Context.MODE_PRIVATE);
		initImageLoader(getApplicationContext());
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
		user = null;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
		setRole(user.getUser_role());
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public void setResDefaultTime(String time_) {
		Editor editor = _preferences.edit();
		editor.putString(RES_DEFAULT_TIME, time_);
		editor.commit();
	}

	public String getResDefaultTime() {
		return _preferences.getString(RES_DEFAULT_TIME, "刚刚");
	}

	public static void initImageLoader(Context context) {
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.discCacheFileNameGenerator(new Md5FileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.writeDebugLogs() // Remove for release app
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}
}
