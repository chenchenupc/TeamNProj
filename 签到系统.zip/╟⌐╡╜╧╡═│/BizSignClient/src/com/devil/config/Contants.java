package com.devil.config;

/**
 * 配置一些常量，静态变量
 * 
 */
public class Contants {
	/* 请求服务端 */
	public static final String BASE_URL = "http://192.168.23.1:8080/BizSignServer/";
	public static final String IMAGE_URL = BASE_URL + "icons/";
	public static final String LOGIN_URL = "LoginServlet";// 登录
	public static final String REGIST_URL = "RegistServlet";// 注册
	public static final String GET_ALL_YG = "GetAllYGServlet";// 获取所有员工信息
	public static final String UPDATE_USR = "EditUserServlet";// 编辑员工信息
	public static final String ZG_ADD_SIGN = "ZGAddSignServlet";// 主管发布签到
	public static final String ZG_ALL_SIGNS = "ZGgetAllSignsServlet";// 主管自己发布过的签到信息
	public static final String ZG_GET_SIGN = "GetYGSignServlet";// 主管根据编码获取签到统计信息
	public static final String YG_GET_SIGN = "YGGetSignsServlet";// 员工获取发布给自己的签到信息
	public static final String YG_DO_SIGN = "YGDoSignServlet";// 员工签到

	/* 服务端返回的结果 */
	public static final String RES_OK = "000000";
	public static final String RES_ERR = "999999";

	public static final String NET_CONN_ERROR = "netException";
	public static final String SERVER_CONN_ERROR = "webException";
	public static final String NET_EXCEPTION = "exception";
	public static final String REQUEST_YES = "yes";
	public static final String REQUEST_NO = "no";
	public static final String REQUEST_NULL = "null";
	public static final String ERROR = "ERROR";
	public static final String SUCCESS = "SUCCESS";
	public static final String EXIST = "EXIST";// 用户已存在
	/* inten跳转状态码 */
	public static final String REQUEST_CODE = "requstCode";
	public static final int SEARCH_TO_RESULT = 1;
	public static final int LIST_TO_RESULT = 2;
	public static final int COLLECT_TO_RESULT = 3;
	public static final int PUBLISH_TO_RESULT = 7;

	public static final int USER_TO_LOGIN = 4;
	public static final int COLLECT_TO_LOGIN = 5;
	public static final int PUBLISH_TO_LOGIN = 6;

	public static String DIALOG_TITLE = "移动签到温馨提示";
	public static String DIALOG_OK = "确定";
	public static String DIALOG_CANCEL = "取消";

}
