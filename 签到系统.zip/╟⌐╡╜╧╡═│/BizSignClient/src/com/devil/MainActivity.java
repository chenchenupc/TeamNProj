package com.devil;

import java.util.HashMap;

import com.devil.fragment.HomeFragment;
import com.devil.fragment.MineFragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends BaseActivity implements OnClickListener {
	private int[] ids = new int[] { R.id.main_tab_account,
			R.id.main_tab_function /* , R.id.main_tab_more */};// 屏蔽第三组Fragment
	private FragmentManager fm;
	private String currentFName;
	private HashMap<String, Fragment> fragments;
	private HomeFragment first;
	private MineFragment second;
	// private ThreeFragment three;
	FragmentTransaction fragmentTransation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_main);
		setTitle("");
		setVisibileBackBtn(false);
		setVisibileTitile(false);
		initView();
	}

	private void initView() {
		for (int i = 0; i < ids.length; i++) {
			findViewById(ids[i]).setOnClickListener(this);
		}

		fm = getSupportFragmentManager();
		fragments = new HashMap<String, Fragment>();

		FragmentTransaction transation = fm.beginTransaction();

		first = new HomeFragment();
		fragments.put("app", first);

		transation.add(R.id.frame_content, first);
		transation.commit();
		currentFName = "app";
		switchStatus(1);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.main_tab_account:
			fragmentTransation = fm.beginTransaction();
			if (null == second) {
				fragmentTransation.hide(fragments.get(currentFName));
				second = new MineFragment();
				fragmentTransation.add(R.id.frame_content, second);
				fragments.put("account", second);
				fragmentTransation.commit();
			} else {
				fragmentTransation.hide(fragments.get(currentFName));
				fragmentTransation.show(second);
				fragmentTransation.commit();
			}
			currentFName = "account";
			switchStatus(2);
			second.onResume();
			break;
		case R.id.main_tab_function:
			fragmentTransation = fm.beginTransaction();
			if (null == first) {
				fragmentTransation.hide(fragments.get(currentFName));
				first = new HomeFragment();
				fragmentTransation.add(R.id.frame_content, first);
				fragments.put("app", first);
				fragmentTransation.commit();

			} else {
				fragmentTransation.hide(fragments.get(currentFName));
				fragmentTransation.show(first);
				fragmentTransation.commit();
			}
			currentFName = "app";
			switchStatus(1);
			first.onResume();
			break;

		// case R.id.main_tab_more:
		// fragmentTransation = fm.beginTransaction();
		// if (null == three) {
		// fragmentTransation.hide(fragments.get(currentFName));
		// three = new ThreeFragment();
		// fragmentTransation.add(R.id.frame_content, three);
		// fragments.put("more", three);
		// fragmentTransation.commit();
		// } else {
		// fragmentTransation.hide(fragments.get(currentFName));
		// fragmentTransation.show(three);
		// fragmentTransation.commit();
		// }
		// currentFName = "more";
		// switchStatus(3);
		// break;
		}
	}

	private void switchStatus(int which) {
		try {

			if (which == 1) {
				((ImageView) findViewById(R.id.main_tab_iv1))
						.setImageDrawable(getResources().getDrawable(
								R.drawable.icon_home_pressed));
				((ImageView) findViewById(R.id.main_tab_iv2))
						.setImageDrawable(getResources().getDrawable(
								R.drawable.icon_administration_normal));
				// ((ImageView) findViewById(R.id.main_tab_iv3))
				// .setImageDrawable(getResources().getDrawable(
				// R.drawable.teb_me_off));
				((TextView) findViewById(R.id.main_tab_tv1))
						.setTextColor(getResources()
								.getColor(R.color.baseColor));
				((TextView) findViewById(R.id.main_tab_tv2))
						.setTextColor(getResources().getColor(R.color.grey));
				// ((TextView) findViewById(R.id.main_tab_tv3))
				// .setTextColor(getResources().getColor(R.color.grey));
			} else if (which == 2) {
				((ImageView) findViewById(R.id.main_tab_iv1))
						.setImageDrawable(getResources().getDrawable(
								R.drawable.icon_home_normal));
				((ImageView) findViewById(R.id.main_tab_iv2))
						.setImageDrawable(getResources().getDrawable(
								R.drawable.icon_administration_pressed));
				// ((ImageView) findViewById(R.id.main_tab_iv3))
				// .setImageDrawable(getResources().getDrawable(
				// R.drawable.teb_me_off));
				((TextView) findViewById(R.id.main_tab_tv1))
						.setTextColor(getResources().getColor(R.color.grey));
				((TextView) findViewById(R.id.main_tab_tv2))
						.setTextColor(getResources()
								.getColor(R.color.baseColor));
				// ((TextView) findViewById(R.id.main_tab_tv3))
				// .setTextColor(getResources().getColor(R.color.grey));
			}
			// else {
			// ((ImageView) findViewById(R.id.main_tab_iv1))
			// .setImageDrawable(getResources().getDrawable(
			// R.drawable.teb_home_off));
			// ((ImageView) findViewById(R.id.main_tab_iv2))
			// .setImageDrawable(getResources().getDrawable(
			// R.drawable.teb_explore_off));
			// ((ImageView) findViewById(R.id.main_tab_iv3))
			// .setImageDrawable(getResources().getDrawable(
			// R.drawable.teb_me_on));
			// ((TextView) findViewById(R.id.main_tab_tv1))
			// .setTextColor(getResources().getColor(R.color.grey));
			// ((TextView) findViewById(R.id.main_tab_tv2))
			// .setTextColor(getResources().getColor(R.color.grey));
			// ((TextView) findViewById(R.id.main_tab_tv3))
			// .setTextColor(getResources().getColor(R.color.base));
			// }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
