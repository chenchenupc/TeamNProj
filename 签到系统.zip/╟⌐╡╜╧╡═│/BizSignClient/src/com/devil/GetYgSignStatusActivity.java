package com.devil;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.devil.BaseActivity;
import com.devil.adapter.ZGSignAdapter;
import com.devil.bean.ResMessage;
import com.devil.bean.SignDto;
import com.devil.config.Contants;
import com.devil.utils.DevilUtil;
import com.devil.utils.HttpUtil;
import com.devil.utils.JsonUtil;
import com.devil.widget.EmptyLayout;
import com.devil.widget.XListView;
import com.devil.widget.XListView.IXListViewListener;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

/**
 * 
 * @ClassName: GetYgSignStatusActivity
 * @Description: 获取员工签到情况信息
 * @date 2016年7月3日 下午11:05:17
 *
 */
public class GetYgSignStatusActivity extends BaseActivity implements
		IXListViewListener {
	private Context context;
	@ViewInject(R.id.all_yg_list)
	XListView lv_clazz;
	private ZGSignAdapter adapter;
	private EmptyLayout mEmptyLayout;
	private List<SignDto> datas = new ArrayList<SignDto>();
	Handler mHandler = new Handler();
	private String signCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_all_yg);
		ViewUtils.inject(this);
		signCode = getIntent().getStringExtra("sign");
		context = this;
		setTitle("签到统计");
		setVisibileBackBtn(true);
		adapter = new ZGSignAdapter(context, datas, 1);
		lv_clazz = (XListView) findViewById(R.id.all_yg_list);
		lv_clazz.setAdapter(adapter);
		lv_clazz.setPullLoadEnable(false);// 上拉加载
		lv_clazz.setXListViewListener(this);// 上下拉监听
		mEmptyLayout = new EmptyLayout(this, lv_clazz);
		mEmptyLayout.setErrorButtonClickListener(mErrorClickListener);
		loadData();
	}

	private View.OnClickListener mErrorClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			mEmptyLayout.showLoading();
		}
	};

	private void loadData() {
		new GetYGSignList().execute(signCode);
	}

	/**
	 * 
	 * @ClassName: GetYGSignList
	 * @Description: 根据签到编码获取签到统计信息
	 * @date 2016年7月3日 下午11:15:22
	 *
	 */
	private class GetYGSignList extends AsyncTask<String, Void, String> {

		String url = Contants.BASE_URL + Contants.ZG_GET_SIGN;

		@Override
		protected String doInBackground(String... params) {
			String result = HttpUtil.postHttpResponseText(url, params[0]);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mEmptyLayout.showLoading();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(context, msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						datas = JsonUtil.parseList(msg.getRES_DATA(),
								SignDto[].class);
						if (datas.size() < 1) {
							datas.remove(datas);
							adapter.setData(datas);
							adapter.notifyDataSetChanged();
							mEmptyLayout.showEmpty();
						} else {
							adapter.setData(datas);
							adapter.notifyDataSetChanged();
						}
					}
				} catch (Exception e) {
					Toast.makeText(context, res, Toast.LENGTH_SHORT).show();
					mEmptyLayout.showError();
				}
			}

		}
	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				ta.setResDefaultTime(DevilUtil.getCurrentTime());
				onLoad();
			}
		}, 2000);
	}

	@Override
	public void onLoadMore() {
		// TODO Auto-generated method stub
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				onLoad();
			}
		}, 2000);
	}

	private void onLoad() {
		lv_clazz.stopRefresh();
		lv_clazz.stopLoadMore();
		lv_clazz.setRefreshTime(ta.getResDefaultTime());
	}

	@Override
	protected void onResume() {
		loadData();
		super.onResume();
	}
}
