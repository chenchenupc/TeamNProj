package com.devil;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.devil.BaseActivity;
import com.devil.adapter.YGListAdapter;
import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.config.Contants;
import com.devil.utils.DevilUtil;
import com.devil.utils.HttpUtil;
import com.devil.utils.JsonUtil;
import com.devil.widget.EmptyLayout;
import com.devil.widget.XListView;
import com.devil.widget.XListView.IXListViewListener;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

/**
 * 
 * @ClassName: GetAllYGListActivity
 * @Description:获取所有的未编辑过信息的员工信息
 * @date 2016年7月3日 下午4:52:33
 *
 */
public class GetAllYGListActivity extends BaseActivity implements
		OnItemClickListener, IXListViewListener {
	private Context context;
	@ViewInject(R.id.all_yg_list)
	XListView lv_clazz;
	private YGListAdapter adapter;
	private EmptyLayout mEmptyLayout;
	private List<UserDto> datas = new ArrayList<UserDto>();
	private List<UserDto> tmps = new ArrayList<UserDto>();
	Handler mHandler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_all_yg);
		ViewUtils.inject(this);
		context = this;
		setTitle("员工信息");
		setVisibileBackBtn(true);
		adapter = new YGListAdapter(context, datas);
		lv_clazz = (XListView) findViewById(R.id.all_yg_list);
		lv_clazz.setAdapter(adapter);
		lv_clazz.setOnItemClickListener(this);
		lv_clazz.setPullLoadEnable(false);// 上拉加载
		lv_clazz.setXListViewListener(this);// 上下拉监听
		mEmptyLayout = new EmptyLayout(this, lv_clazz);
		mEmptyLayout.setErrorButtonClickListener(mErrorClickListener);
		loadData();
	}

	private View.OnClickListener mErrorClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			mEmptyLayout.showLoading();
		}
	};

	private void loadData() {
		new GetYGList().execute();
	}

	private class GetYGList extends AsyncTask<Void, Void, String> {

		String url = Contants.BASE_URL + Contants.GET_ALL_YG;

		@Override
		protected String doInBackground(Void... params) {
			String result = HttpUtil.getHttpPostResultForUrl(url);
			return result;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mEmptyLayout.showLoading();
		}

		@Override
		protected void onPostExecute(String res) {
			super.onPostExecute(res);
			if (res != null) {
				try {
					ResMessage msg = JsonUtil.parse(res, ResMessage.class);
					if (msg == null)
						return;
					Toast.makeText(context, msg.getRES_MESSAGE(),
							Toast.LENGTH_SHORT).show();
					if (msg.getRES_CODE().equals(Contants.RES_OK)) {
						tmps = JsonUtil.parseList(msg.getRES_DATA(),
								UserDto[].class);
						datas.removeAll(datas);
						for (UserDto ud : tmps) {
							if (ud.getUser_status() == 0)
								datas.add(ud);
						}
						if (datas.size() < 1) {
							adapter.setData(datas);
							adapter.notifyDataSetChanged();
							mEmptyLayout.showEmpty();
						} else {
							adapter.setData(datas);
							adapter.notifyDataSetChanged();
						}
					}
				} catch (Exception e) {
					Toast.makeText(context, res, Toast.LENGTH_SHORT).show();
					mEmptyLayout.showError();
				}
			}

		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		UserDto dto = datas.get(arg2 - 1);
		Intent intent = new Intent(GetAllYGListActivity.this,
				EditUserActivity.class);
		intent.putExtra("user", JsonUtil.format(dto));
		startActivity(intent);
	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				ta.setResDefaultTime(DevilUtil.getCurrentTime());
				onLoad();
			}
		}, 2000);
	}

	@Override
	public void onLoadMore() {
		// TODO Auto-generated method stub
		loadData();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				onLoad();
			}
		}, 2000);
	}

	private void onLoad() {
		lv_clazz.stopRefresh();
		lv_clazz.stopLoadMore();
		lv_clazz.setRefreshTime(ta.getResDefaultTime());
	}

	@Override
	protected void onResume() {
		loadData();
		super.onResume();
	}
}
