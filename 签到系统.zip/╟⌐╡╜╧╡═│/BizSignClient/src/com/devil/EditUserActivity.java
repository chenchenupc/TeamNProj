package com.devil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.config.Contants;
import com.devil.utils.JsonUtil;
import com.devil.utils.MyHttpUtils;
import com.devil.utils.MyHttpUtils.JsonCallBack;
import com.devil.utils.PublicUtil;
import com.devil.widget.IputEditText;
import com.devil.widget.PopupDialog;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.nostra13.universalimageloader.core.ImageLoader;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

/**
 * 
 * @ClassName: EditUserActivity
 * @Description: 编辑或显示用户信息
 * @date 2016年7月3日 下午5:13:34
 *
 */
public class EditUserActivity extends BaseActivity {
	UserDto ud;
	@ViewInject(R.id.iv)
	ImageView iv_icon;
	@ViewInject(R.id.upload)
	Button btn_ok;
	@ViewInject(R.id.yg_name)
	IputEditText et_name;
	@ViewInject(R.id.yg_id)
	EditText et_id;
	@ViewInject(R.id.rg_role)
	RadioGroup rg;
	@ViewInject(R.id.yg_nan)
	RadioButton rg_nan;
	@ViewInject(R.id.yg_nv)
	RadioButton rg_nv;

	@ViewInject(R.id.yg_detail_name)
	TextView tv_d_name;
	@ViewInject(R.id.yg_detail_sex)
	TextView tv_d_sex;
	@ViewInject(R.id.yg_detail_id)
	TextView tv_d_id;

	public final static int PHOTO_ZOOM = 1001;// 相册选择照片
	public final static int PHOTO_RESULT = 1002;
	public final static int TAKE_PHOTO = 1003;// 拍照
	public static final String IMAGE_UNSPECIFIED = "image/*";
	// 创建一个以当前系统时间为名称的文件，防止重复
	private File file = new File(Environment.getExternalStorageDirectory(),
			getPhotoFileName());
	private File uploadFile;
	private boolean isSet = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setChildContentView(R.layout.activity_edit_user);
		ViewUtils.inject(this);
		String data = getIntent().getStringExtra("user");
		if (data == null) {
			ud = ta.getUser();
			btn_ok.setVisibility(View.GONE);
			et_name.setVisibility(View.GONE);
			et_id.setVisibility(View.GONE);
			rg.setVisibility(View.GONE);
			iv_icon.setClickable(false);
			tv_d_name.setVisibility(View.VISIBLE);
			tv_d_name.setText(ud.getUser_name());
			tv_d_sex.setVisibility(View.VISIBLE);
			tv_d_sex.setText(ud.getUser_sex());
			tv_d_id.setVisibility(View.VISIBLE);
			tv_d_id.setText(ud.getUser_id());
			ImageLoader.getInstance().displayImage(
					Contants.IMAGE_URL + ud.getUser_icon(), iv_icon);
		} else {
			ud = JsonUtil.parse(data, UserDto.class);
			ud.setUser_sex("男");
			iv_icon.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					new AvatarDialog(EditUserActivity.this).show();
				}
			});
			btn_ok.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					String name = et_name.getText().toString();
					String id = et_id.getText().toString();
					if (!isSet) {
						Toast.makeText(EditUserActivity.this, "请设置员工头像！",
								Toast.LENGTH_SHORT).show();
						return;
					}
					if (PublicUtil.isEmptryStr(name)) {
						Toast.makeText(EditUserActivity.this, "员工姓名不能为空！",
								Toast.LENGTH_SHORT).show();
						return;
					}
					ud.setUser_name(name);
					if (PublicUtil.isEmptryStr(id)
							|| !PublicUtil.isIdCardNum(id)) {
						Toast.makeText(EditUserActivity.this, "员工身份证号格式错误！",
								Toast.LENGTH_SHORT).show();
						return;
					}
					ud.setUser_id(id);
					send();
				}
			});
			rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(RadioGroup arg0, int index) {
					if (arg0.getCheckedRadioButtonId() == R.id.yg_nan) {
						ud.setUser_sex("男");
					} else {
						ud.setUser_sex("女");
					}
				}
			});
		}
		setTitle(ud.getUser_nickName());

	}

	protected class AvatarDialog extends PopupDialog {

		public AvatarDialog(Context context) {
			super(context, R.style.dialog_share, R.layout.dialog_profile_avatar);

			View view = getLayoutInflater().inflate(
					R.layout.dialog_profile_avatar, null);
			this.setContentView(view);

			Button BT_cancel = (Button) view
					.findViewById(R.id.dialog_profile_cancel);
			BT_cancel
					.setOnClickListener(new android.view.View.OnClickListener() {

						@Override
						public void onClick(View v) {
							AvatarDialog.this.dismiss();
						}
					});

			Button BT_takePicture = (Button) view
					.findViewById(R.id.dialog_profile_take_picture);
			BT_takePicture
					.setOnClickListener(new android.view.View.OnClickListener() {

						@Override
						public void onClick(View v) {
							AvatarDialog.this.dismiss();
							Intent intent = new Intent(
									MediaStore.ACTION_IMAGE_CAPTURE);
							intent.putExtra(MediaStore.EXTRA_OUTPUT,
									Uri.fromFile(file));
							startActivityForResult(intent, TAKE_PHOTO);
						}
					});

			Button bT_takeImagePick = (Button) view
					.findViewById(R.id.dialog_profile_take_ImagePick);
			bT_takeImagePick
					.setOnClickListener(new android.view.View.OnClickListener() {

						@Override
						public void onClick(View v) {
							AvatarDialog.this.dismiss();
							Intent intent = new Intent(Intent.ACTION_PICK);
							intent.setType("image/*");
							startActivityForResult(intent, PHOTO_ZOOM);
						}
					});
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK) {
			return;
		}
		// 判断是否有SD卡
		
		if (requestCode == PHOTO_ZOOM) {
			String[] proj = { MediaStore.Images.Media.DATA };
			@SuppressWarnings("deprecation")
			Cursor cursor = this.managedQuery(data.getData(), proj, null, null,
					null);
			int column_index = cursor
					.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			String pathstr = cursor.getString(column_index);
			uploadFile = new File(pathstr);
			photoZoom(data.getData());
		}
		if (requestCode == TAKE_PHOTO) {
			uploadFile = file;
			photoZoom(Uri.fromFile(uploadFile));
		}

		if (requestCode == PHOTO_RESULT) {
			Bundle extras = data.getExtras();
			if (extras != null) {
				Bitmap photo = extras.getParcelable("data");
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				photo.compress(Bitmap.CompressFormat.JPEG, 75, stream);
				iv_icon.setVisibility(View.VISIBLE);
				iv_icon.setImageBitmap(photo);
				isSet = true;

			}
		}
	}

	// 图片缩放
	public void photoZoom(Uri uri) {
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, IMAGE_UNSPECIFIED);
		intent.putExtra("crop", "true");
		// aspectX aspectY 是宽高的比例
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		// outputX outputY 是裁剪图片宽高
		intent.putExtra("outputX", 250);
		intent.putExtra("outputY", 250);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, PHOTO_RESULT);
	}

	// 使用系统当前日期加以调整作为照片的名称
	private String getPhotoFileName() {
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		return sdf.format(date) + ".jpg";
	}

	private void send() {
		showLoadingDialog();
		String requestURL = Contants.BASE_URL + Contants.UPDATE_USR;
		RequestParams params = new RequestParams();
		String mime = MimeTypeMap.getSingleton()
				.getMimeTypeFromExtension("jpg");
		params.addBodyParameter("upfile", uploadFile, mime);
		params.addBodyParameter("user", JsonUtil.format(ud));
		// params.addBodyParameter("key"," value");//如果上传文件的接口也支持上传其他的参数，就可以启用这个了
		// 请求方法是自己封装的，用的是post请求，参数是；接口、参数、回调方法
		MyHttpUtils.parseShareJsonFromNet(requestURL, params,
				new JsonCallBack() {

					@Override
					public void callback(String jsonStr) {
						dismissLoadingDialog();
						if (jsonStr != null) {
							ResMessage msg = JsonUtil.parse(jsonStr,
									ResMessage.class);
							if (msg == null)
								return;
							Toast.makeText(getApplicationContext(),
									msg.getRES_MESSAGE(), Toast.LENGTH_SHORT)
									.show();
							if (msg.getRES_CODE().equals(Contants.RES_OK)) {
								finish();
							}
						}
					}
				});
	}
}
