CREATE DATABASE  IF NOT EXISTS `sign_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `sign_db`;
-- MySQL dump 10.13  Distrib 5.6.19, for osx10.7 (i386)
--
-- Host: localhost    Database: sign_db
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SignInfo`
--

DROP TABLE IF EXISTS `SignInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SignInfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sign_code` varchar(50) DEFAULT NULL COMMENT '签到信息编号',
  `sign_des` varchar(256) DEFAULT NULL COMMENT '签到内容简述',
  `sign_time` varchar(50) DEFAULT NULL COMMENT '签到发布时间',
  `sign_status` int(2) DEFAULT NULL COMMENT '签到状态 0-待签到  1-已签到',
  `sign_pass` varchar(50) DEFAULT NULL COMMENT '签到密码',
  `u_id` int(50) DEFAULT NULL COMMENT '用户ID',
  `u_role` int(10) DEFAULT NULL COMMENT '用户角色',
  `u_name` varchar(50) DEFAULT NULL COMMENT '姓名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SignInfo`
--

LOCK TABLES `SignInfo` WRITE;
/*!40000 ALTER TABLE `SignInfo` DISABLE KEYS */;
INSERT INTO `SignInfo` VALUES (50,'df740ae7-bf72-48ac-a9f7-6bec41e6521c','搬砖啦','2016-07-03 22:36:33',0,'098196',40,0,NULL),(51,'df740ae7-bf72-48ac-a9f7-6bec41e6521c','搬砖啦','2016-07-03 22:36:33',1,'098196',39,1,'机器'),(52,'df740ae7-bf72-48ac-a9f7-6bec41e6521c','搬砖啦','2016-07-03 22:36:33',0,'098196',41,1,'张三'),(53,'126fc99f-c4d1-41a2-9dbe-bcd6ae0a3921','旮旯我想去','2016-07-03 22:59:13',0,'737188',40,0,NULL),(54,'126fc99f-c4d1-41a2-9dbe-bcd6ae0a3921','旮旯我想去','2016-07-03 22:59:13',1,'737188',39,1,'机器'),(55,'126fc99f-c4d1-41a2-9dbe-bcd6ae0a3921','旮旯我想去','2016-07-03 22:59:13',1,'737188',41,1,'张三');
/*!40000 ALTER TABLE `SignInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserInfo`
--

DROP TABLE IF EXISTS `UserInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserInfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_loginName` varchar(50) DEFAULT NULL COMMENT '登录名',
  `user_pass` varchar(50) DEFAULT NULL COMMENT '密码',
  `user_nickName` varchar(50) DEFAULT NULL COMMENT '昵称',
  `user_role` int(2) DEFAULT NULL COMMENT '角色 0-主管  1-员工',
  `user_name` varchar(50) DEFAULT NULL COMMENT '员工姓名',
  `user_sex` varchar(10) DEFAULT NULL COMMENT '员工性别',
  `user_id` varchar(30) DEFAULT NULL COMMENT '员工身份证号',
  `user_icon` varchar(256) DEFAULT NULL COMMENT '员工头像',
  `user_status` int(2) DEFAULT NULL COMMENT '用户信息状态,0-未编辑信息  1-已编辑过信息',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserInfo`
--

LOCK TABLES `UserInfo` WRITE;
/*!40000 ALTER TABLE `UserInfo` DISABLE KEYS */;
INSERT INTO `UserInfo` VALUES (39,'111','111','改了',1,'机器','男','421024195607098759','111.jpg',1),(40,'123','123','主管大人',0,NULL,NULL,NULL,NULL,NULL),(41,'222','222','222',1,'张三','男','421024152308087896','222.jpg',1),(42,'555','555','555',1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `UserInfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-04 11:52:16
