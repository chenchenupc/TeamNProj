package com.devil.util;

/**
 * 服务端自定义状态码
 *
 */
public class Contants {

	public static final String RES_OK = "000000";
	public static final String RES_ERR = "999999";
}
