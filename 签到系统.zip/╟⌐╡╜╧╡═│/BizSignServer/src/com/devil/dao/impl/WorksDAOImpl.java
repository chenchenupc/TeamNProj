package com.devil.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.devil.bean.SignDto;
import com.devil.bean.UserDto;
import com.devil.dao.WorksDAO;
import com.devil.util.ConnDB;

/**
 * 
 * @ClassName: WorksDAOImpl
 * @Description: 实现接口
 * @date 2016年7月3日 下午12:13:29
 *
 */
public class WorksDAOImpl implements WorksDAO {
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;

	// 注册:先查询用户是否存在、再添加
	public boolean addUser(UserDto registerDto) {
		conn = ConnDB.getConn();
		String sql = "";
		sql = "select * from UserInfo where user_loginName=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, registerDto.getUser_loginName());
			rs = ps.executeQuery();
			while (rs.next()) {
				return false;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		conn = ConnDB.getConn();
		sql = "insert into UserInfo (user_loginName,user_pass,user_nickName,user_role) values (?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, registerDto.getUser_loginName());
			ps.setString(2, registerDto.getUser_pass());
			ps.setString(3, registerDto.getUser_nickName());
			ps.setInt(4, registerDto.getUser_role());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return true;
	}

	// 登录
	public UserDto loginUser(UserDto loginDto) {
		conn = ConnDB.getConn();
		String sql = "";
		UserDto usrDto = new UserDto();
		sql = "select * from UserInfo where user_loginName=? and user_pass = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, loginDto.getUser_loginName());
			ps.setString(2, loginDto.getUser_pass());
			rs = ps.executeQuery();
			while (rs.next()) {
				usrDto.setId(rs.getInt("id"));
				usrDto.setUser_loginName(loginDto.getUser_loginName());
				usrDto.setUser_pass(loginDto.getUser_pass());
				usrDto.setUser_nickName(rs.getString("user_nickName"));
				usrDto.setUser_role(rs.getInt("user_role"));
				usrDto.setUser_name(rs.getString("user_name"));
				usrDto.setUser_sex(rs.getString("user_sex"));
				usrDto.setUser_id(rs.getString("user_id"));
				usrDto.setUser_icon(rs.getString("user_icon"));
				return usrDto;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return null;
	}

	// 根据ID获取用户信息
	public UserDto getUserById(int id) {
		conn = ConnDB.getConn();
		String sql = "";
		UserDto usrDto = new UserDto();
		sql = "select * from UserInfo where id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				usrDto.setId(id);
				usrDto.setUser_loginName(rs.getString("user_loginName"));
				usrDto.setUser_pass(rs.getString("user_pass"));
				usrDto.setUser_name(rs.getString("user_name"));
				usrDto.setUser_nickName(rs.getString("user_nickName"));
				usrDto.setUser_role(rs.getInt("user_role"));
				usrDto.setUser_sex(rs.getString("user_sex"));
				usrDto.setUser_id(rs.getString("user_id"));
				usrDto.setUser_icon(rs.getString("user_icon"));
				return usrDto;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return null;
	}

	private String getCurrentTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}

	// 获取所有员工信息,用于发布签到
	@Override
	public List<UserDto> getAllYG() {
		conn = ConnDB.getConn();
		List<UserDto> list = new ArrayList<UserDto>();
		String sql = "select * from UserInfo where user_role=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, 1);
			rs = ps.executeQuery();
			while (rs.next()) {
				UserDto ca = new UserDto();
				ca.setId(rs.getInt("id"));
				ca.setUser_role(rs.getInt("user_role"));
				ca.setUser_name(rs.getString("user_name"));
				ca.setUser_nickName(rs.getString("user_nickName"));
				ca.setUser_loginName(rs.getString("user_loginName"));
				ca.setUser_status(rs.getInt("user_status"));
				list.add(ca);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return list;
	}

	@Override
	public boolean updateUser(UserDto user) {
		// TODO Auto-generated method stub
		conn = ConnDB.getConn();
		String sql = "update UserInfo set user_name = ?,user_sex = ?,user_id = ?,user_icon = ? ,user_status = ? where id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getUser_name());
			ps.setString(2, user.getUser_sex());
			ps.setString(3, user.getUser_id());
			ps.setString(4, user.getUser_icon());
			ps.setInt(5, 1);
			ps.setInt(6, user.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return true;
	}

	@Override
	public boolean addSign(SignDto sd) {
		conn = ConnDB.getConn();
		String sql = "insert into SignInfo (sign_code,sign_des,sign_time,sign_status,sign_pass,u_id,u_role,u_name) values (?,?,?,?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, sd.getSign_code());
			ps.setString(2, sd.getSign_des());
			ps.setString(3, getCurrentTime());
			ps.setInt(4, sd.getSign_status());
			ps.setString(5, sd.getSign_pass());
			ps.setInt(6, sd.getU_id());
			ps.setInt(7, sd.getU_role());
			ps.setString(8, sd.getU_name());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return true;
	}

	@Override
	public List<SignDto> zGetSigns(int id) {
		conn = ConnDB.getConn();
		List<SignDto> list = new ArrayList<SignDto>();
		String sql = "select * from SignInfo where u_id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				SignDto sd = new SignDto();
				sd.setId(rs.getInt("id"));
				sd.setSign_code(rs.getString("sign_code"));
				sd.setSign_des(rs.getString("sign_des"));
				sd.setSign_pass(rs.getString("sign_pass"));
				sd.setSign_time(rs.getString("sign_time"));
				list.add(sd);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return list;
	}

	@Override
	public List<SignDto> zGetSignsByCode(String code) {
		conn = ConnDB.getConn();
		List<SignDto> list = new ArrayList<SignDto>();
		String sql = "select * from SignInfo where sign_code=? and u_role=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, code);
			ps.setInt(2, 1);// 获取所有员工的签到情况信息
			rs = ps.executeQuery();
			while (rs.next()) {
				SignDto sd = new SignDto();
				sd.setId(rs.getInt("id"));
				sd.setSign_code(rs.getString("sign_code"));
				sd.setSign_des(rs.getString("sign_des"));
				sd.setSign_pass(rs.getString("sign_pass"));
				sd.setSign_time(rs.getString("sign_time"));
				sd.setU_name(rs.getString("u_name"));
				sd.setU_id(rs.getInt("u_id"));
				sd.setU_role(rs.getInt("u_role"));
				list.add(sd);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return list;
	}

	@Override
	public List<SignDto> yGetSigns(int uId) {
		// TODO Auto-generated method stub
		conn = ConnDB.getConn();
		List<SignDto> list = new ArrayList<SignDto>();
		String sql = "select * from SignInfo where  u_id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, uId);// 员工获取自己的签到信息
			rs = ps.executeQuery();
			while (rs.next()) {
				SignDto sd = new SignDto();
				sd.setId(rs.getInt("id"));
				sd.setSign_code(rs.getString("sign_code"));
				sd.setSign_des(rs.getString("sign_des"));
				sd.setSign_pass(rs.getString("sign_pass"));
				sd.setSign_time(rs.getString("sign_time"));
				sd.setU_name(rs.getString("u_name"));
				sd.setU_id(rs.getInt("u_id"));
				sd.setU_role(rs.getInt("u_role"));
				sd.setSign_status(rs.getInt("sign_status"));
				list.add(sd);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return list;
	}

	@Override
	public boolean ySign(SignDto sd) {
		String pass = "";
		conn = ConnDB.getConn();
		String sql = "";
		sql = "select * from SignInfo where u_id = ? and sign_code = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, sd.getU_id());
			ps.setString(2, sd.getSign_code());
			rs = ps.executeQuery();
			while (rs.next()) {
				pass = rs.getString("sign_pass");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		if (!sd.getSign_pass().equals(pass))
			return false;
		conn = ConnDB.getConn();
		sql = "update SignInfo set sign_status = ? where id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, 1);
			ps.setInt(2, sd.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnDB.closeConn(conn);
		}
		return true;
	}
}
