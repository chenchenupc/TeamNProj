package com.devil.dao;

import java.util.List;

import com.devil.bean.SignDto;
import com.devil.bean.UserDto;

/**
 * 
 * @ClassName: WorksDAO
 * @Description: 定义接口
 * @date 2016年7月3日 下午12:03:56
 *
 */
public interface WorksDAO {

	// 注册
	public boolean addUser(UserDto registerDto);

	// 登录
	public UserDto loginUser(UserDto loginDto);

	// 根据ID获取用户信息
	public UserDto getUserById(int id);

	// 获取所有员工信息
	public List<UserDto> getAllYG();

	// 编辑员工信息
	public boolean updateUser(UserDto user);

	// 主管发布签到信息
	public boolean addSign(SignDto sd);

	// 主管获取自己发布的所有签到信息
	public List<SignDto> zGetSigns(int id);

	// 主管根据签到编号查询所有员工的签到情况
	public List<SignDto> zGetSignsByCode(String code);

	// 员工获取自己相关的所有签到信息
	public List<SignDto> yGetSigns(int uId);

	// 员工进行签到
	public boolean ySign(SignDto sd);

}
