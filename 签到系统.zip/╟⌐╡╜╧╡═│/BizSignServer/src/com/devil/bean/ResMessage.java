package com.devil.bean;

/**
 * 
 * @ClassName: ResMessage
 * @Description: 服务端和app端数据交互json数据实体
 * @date 2016年7月3日 下午12:02:17
 *
 */
public class ResMessage {
	private String RES_CODE;// 状态码
	private String RES_MESSAGE;// 自定义描述
	private String RES_DATA;// json数据

	public String getRES_CODE() {
		return RES_CODE;
	}

	public void setRES_CODE(String rES_CODE) {
		RES_CODE = rES_CODE;
	}

	public String getRES_MESSAGE() {
		return RES_MESSAGE;
	}

	public void setRES_MESSAGE(String rES_MESSAGE) {
		RES_MESSAGE = rES_MESSAGE;
	}

	public String getRES_DATA() {
		return RES_DATA;
	}

	public void setRES_DATA(String rES_DATA) {
		RES_DATA = rES_DATA;
	}

}
