package com.devil.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.dao.WorksDAO;
import com.devil.dao.impl.WorksDAOImpl;
import com.devil.util.Contants;
import com.devil.util.JsonUtil;

/**
 * App注册接口
 * 
 */
@SuppressWarnings("all")
public class RegistServlet extends HttpServlet {

	public RegistServlet() {
		super();
	}

	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/hmtl;charset=utf-8");
		PrintWriter out = response.getWriter();
		// 当正确响应时处理数据
		StringBuffer buffer = new StringBuffer();
		String readLine = null;
		// 处理响应流，必须与服务器响应流输出的编码一致
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				request.getInputStream(), "UTF-8"));
		while ((readLine = reader.readLine()) != null) {
			buffer.append(readLine).append("\n");
		}
		reader.close();
		UserDto registerDto = JsonUtil.parse(buffer.toString(), UserDto.class);
		WorksDAO chengDAO = new WorksDAOImpl();
		boolean flag = chengDAO.addUser(registerDto);
		ResMessage msg = new ResMessage();
		if (!flag) {
			msg.setRES_CODE(Contants.RES_ERR);
			msg.setRES_MESSAGE("该用户名已被注册!");
		} else {
			msg.setRES_CODE(Contants.RES_OK);
			msg.setRES_MESSAGE("注册成功!");
		}
		out.print(JsonUtil.format(msg));
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
