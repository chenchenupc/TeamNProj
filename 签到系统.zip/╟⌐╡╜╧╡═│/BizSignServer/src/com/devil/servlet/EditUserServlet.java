package com.devil.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;

import Decoder.BASE64Decoder;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.dao.WorksDAO;
import com.devil.dao.impl.WorksDAOImpl;
import com.devil.util.Contants;
import com.devil.util.JsonUtil;

/**
 * 
 * @ClassName: EditUserServlet
 * @Description: 编辑用户信息
 * @date 2016年7月3日 下午5:49:41
 *
 */
@SuppressWarnings("all")
public class EditUserServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public EditUserServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/hmtl;charset=utf-8");
		PrintWriter out = response.getWriter();
		String temp = request.getSession().getServletContext().getRealPath("/")
				+ "temp"; // 临时目录
		// System.out.println("temp=" + temp);
		File file = new File(temp);
		if (!file.exists()) {
			file.mkdirs();
		}
		String loadpath = request.getSession().getServletContext()
				.getRealPath("/icons"); // 上传文件存放目录
		// System.out.println("loadpath=" + loadpath);
		file = new File(loadpath);
		if (!file.exists()) {
			file.mkdirs();
		}
		DiskFileUpload fu = new DiskFileUpload();
		fu.setSizeMax(10 * 1024 * 1024); // 设置允许用户上传文件大小,单位:字节
		fu.setSizeThreshold(4096); // 设置最多只允许在内存中存储的数据,单位:字节
		fu.setRepositoryPath(temp); // 设置一旦文件大小超过getSizeThreshold()的值时数据存放在硬盘的目录

		// 开始读取上传信息
		int index = 0;
		List fileItems = null;

		try {
			fileItems = fu.parseRequest(request);
			System.out.println("fileItems=" + fileItems);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Iterator iter = fileItems.iterator(); // 依次处理每个上传的文件
		UserDto ud = new UserDto();
		while (iter.hasNext()) {
			FileItem item = (FileItem) iter.next();// 忽略其他不是文件域的所有表单信息
			if (item.isFormField()) {// 取出不是文件域的所有表单信息
				String fieldvalue = item.getString();
				// 如果包含中文应写为：(转为UTF-8编码)
				ud = JsonUtil.parse(fieldvalue, UserDto.class);
			} else {
				String name = item.getName();// 获取上传文件名,包括路径
				ud.setUser_icon(ud.getUser_loginName() + ".jpg");
				File fNew = new File(loadpath, ud.getUser_icon());
				try {
					item.write(fNew);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		WorksDAO wd = new WorksDAOImpl();
		boolean res = wd.updateUser(ud);
		ResMessage msg = new ResMessage();
		if (!res) {
			msg.setRES_CODE(Contants.RES_ERR);
			msg.setRES_MESSAGE("员工信息设置失败!");
		} else {
			msg.setRES_CODE(Contants.RES_OK);
			msg.setRES_MESSAGE("员工信息设置成功");
		}
		out.print(JsonUtil.format(msg));
	}

	public void init() throws ServletException {
		// Put your code here
	}

	/**
	 * 通过BASE64Decoder解码，并生成图片
	 * 
	 * @param imgStr
	 *            解码后的string
	 */
	public boolean string2Image(String imgStr, String imgFilePath) {
		// 对字节数组字符串进行Base64解码并生成图片
		if (imgStr == null)
			return false;
		try {
			// Base64解码
			byte[] b = new BASE64Decoder().decodeBuffer(imgStr);
			for (int i = 0; i < b.length; ++i) {
				if (b[i] < 0) {
					// 调整异常数据
					b[i] += 256;
				}
			}
			// 生成Jpeg图片
			OutputStream out = new FileOutputStream(imgFilePath);
			out.write(b);
			out.flush();
			out.close();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
