package com.devil.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.devil.bean.ResMessage;
import com.devil.bean.UserDto;
import com.devil.dao.WorksDAO;
import com.devil.dao.impl.WorksDAOImpl;
import com.devil.util.Contants;
import com.devil.util.JsonUtil;

/**
 * App端登陆Servlet接口
 * 
 */
@SuppressWarnings("all")
public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/hmtl;charset=utf-8");
		PrintWriter out = response.getWriter();
		// 当正确响应时处理数据
		StringBuffer buffer = new StringBuffer();
		String readLine = null;
		// 处理响应流，必须与服务器响应流输出的编码一致
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				request.getInputStream(), "UTF-8"));
		while ((readLine = reader.readLine()) != null) {
			buffer.append(readLine).append("\n");
		}
		reader.close();
		UserDto usr = JsonUtil.parse(buffer.toString(), UserDto.class);
		WorksDAO chengDAO = new WorksDAOImpl();
		UserDto registerDto = chengDAO.loginUser(usr);
		ResMessage msg = new ResMessage();
		if (registerDto == null) {
			msg.setRES_CODE(Contants.RES_ERR);
			msg.setRES_MESSAGE("登录失败,账号或密码错误,请重试!");
		} else {
			msg.setRES_CODE(Contants.RES_OK);
			msg.setRES_MESSAGE("登录成功");
			msg.setRES_DATA(JsonUtil.format(registerDto));
		}
		out.print(JsonUtil.format(msg));
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
